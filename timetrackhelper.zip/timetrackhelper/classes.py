from datetime import datetime
import pandas as pd
import sqlite3

# Utility class to manage internal database
class User_Preferences:
    def __init__(self):
        return
    
    def reset_preferences(self):
        con = sqlite3.connect("info.db")
        cur = con.cursor()
        cur.execute("DROP TABLE IF EXISTS programs")
        cur.execute("DROP TABLE IF EXISTS activities")
        cur.execute("CREATE TABLE programs (name,active)")
        cur.execute("CREATE TABLE activities (label,active)")
        con.close()

    def store_content(self,content_type,content):
        con = sqlite3.connect("info.db")
        cur = con.cursor()
        cur.execute(f"INSERT INTO {content_type} VALUES (\"{content}\",1)")
        con.commit()
        con.close()

    def store_program(self, program_name=""):
        self.store_content("programs",program_name)

    def store_activity(self,activity_name=""):
        self.store_content("activities",activity_name)

    def get_programs(self):
        return


# Top level grouping of Activities
class Program:
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return f"{self.name}"
    

# One item of work for a Program
class Activity:
    def __init__(self,label,description=""):
        self.label = label
        self.description = description

    def __str__(self):
        return f"{self.label} \t{self.description}"

# Everything needed to record work during a specific period of time
class Entry:
    def __init__(self,program,activity,start=datetime.now(),stop=datetime.now()):
        self.program = program
        self.activity = activity
        self.start = start
        self.stop = stop

    def __str__(self):
        return f"{self.program}: \t{self.activity} | \t\t{self.start} -> {self.stop}"

    def time(self):
        diff = self.stop - self.start
        return f"{diff}"

# Group of Entries stored/read from CSV
class Log:
    def __init__(self,entries=[],csv_name=""):
        self.entries = entries
        self.csv_name = csv_name

    def set_csv_name(self,csv_name):
        self.csv_name = csv_name

    def get_program_entries(self,name):
        found_entries = []
        for entry in self.entries:
            if entry.program.name == name:
                found_entries.append(entry)
        
        return found_entries

    def load_entries_from_csv(self):
        df = pd.read_csv(self.csv_name)

        for row_tuple in df.itertuples():

            this_entry = Entry(Program(row_tuple.Program),Activity(row_tuple.Activity,row_tuple.Description))
            this_entry.start = row_tuple.Start
            this_entry.stop = row_tuple.Stop

            self.entries.append(this_entry)

        return df
    
    def add_to_entries(self,entry):
        self.entries.append(entry)

    def store_entries_in_csv(self,overwrite=False):

        data_for_df = [{"Program":entry.program.name, "Activity":entry.activity.label, "Description":entry.activity.description, 
                        "Start": entry.start, "Stop": entry.stop} for entry in self.entries]

        df = pd.DataFrame(data_for_df)

        # Write to CSV
        if overwrite:
            df.to_csv(self.csv_name, index=False)
        else:
           df.to_csv(self.csv_name,mode='a', header=False, index=False)


