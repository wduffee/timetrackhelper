from classes import *

print("----------------------------------------------------------------------------------------------------------")

'''
new_now = Log()
new_now.set_csv_name('test.csv')
content = new_now.load_entries_from_csv()
print(content)

for item in new_now.get_program_entries("HSS"):
    print(item.program.name)

new_now.set_csv_name('test_write.csv')

new_now.store_entries_in_csv()
new_now.store_entries_in_csv()

new_now.set_csv_name('test_write2.csv')
new_now.store_entries_in_csv()
new_now.store_entries_in_csv(True)

e = Entry(Program("program"),Activity("mylabel"))

new_now.add_to_entries(e)

new_now.set_csv_name('test_write3.csv')
new_now.store_entries_in_csv(True)
'''

up = User_Preferences()

up.reset_preferences()
up.store_activity("myfirst activity")
#up.store_program("new program please")